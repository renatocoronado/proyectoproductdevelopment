import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

import io
import tensorflow as tf
from tensorflow import keras
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pickle

from flask import Flask, request, jsonify, send_file

modelo = keras.models.load_model("sa.h5")

with open('lista_opin.pkl', 'rb') as file:
    lista_cargada = pickle.load(file)

app = Flask(__name__)

def prediccion(texto):
    try:
        tokenizer = Tokenizer(num_words=100000, oov_token="<00V>")
        tokenizer.fit_on_texts(lista_cargada)

        secuencia = tokenizer.texts_to_sequences([texto])
        secuencia_pad = pad_sequences(secuencia, padding="post", maxlen=10000)
        prediccion = modelo.predict(secuencia_pad)

        respuesta = "Positivo" if prediccion > 0.6 else "Negativo"

        return respuesta
    except Exception as e:
        return str(e)

def prediccion_archivo(file_path):
    with open(file_path, 'r') as file:
        opiniones = file.readlines()

    predicciones = [prediccion(opinion) for opinion in opiniones]

    output_file_path = 'predicciones.txt'
    with open(output_file_path, 'w') as output_file:
        output_file.writelines(predicciones)

    return output_file_path

@app.route("/", methods=["POST", "GET"])
def index():
    if request.method == "POST":
        if 'file' not in request.files:
            return jsonify({"Error": "No se proporcionó un archivo"}), 400

        file = request.files['file']

        if file.filename == '':
            return jsonify({"Error": "Archivo vacío"}), 400

        try:
            # Save the file to a temporary location
            file_path = '/tmp/input_file.txt'
            file.save(file_path)

            # Call the prediction function
            predictions_file = prediccion_archivo(file_path)

            # Return the predictions file
            return send_file(predictions_file, as_attachment=True)

        except Exception as e:
            return jsonify({"error": str(e)})

    return "OK"

if __name__ == "__main__":
    app.run(debug=True)